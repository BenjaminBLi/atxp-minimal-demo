# MCP Client Communication Functions

This document outlines the key functions used by the MCP client (`StreamableHTTPClientTransport`) to communicate with the server.

## Main Transport Class

**`StreamableHTTPClientTransport`** - The client transport implementation that handles all communication with the MCP server.

## Key Methods

### 1. `send(message, options)` - Lines 288-416
**Purpose**: Sends JSON-RPC messages to the server via HTTP POST

**What it does**:
- Creates a POST request to the server URL
- Sets headers:
  - `Content-Type: application/json`
  - `Accept: application/json, text/event-stream`
  - `mcp-session-id` (if session exists)
  - `Authorization: Bearer <token>` (if authenticated)
- Serializes the message as JSON in the request body
- Handles responses:
  - **202 Accepted**: Server accepted the request, may start SSE stream
  - **200 OK with JSON**: Direct JSON-RPC response
  - **200 OK with SSE**: Server-Sent Events stream response
  - **401 Unauthorized**: Triggers authentication flow
  - **403 Forbidden**: May trigger upscoping
  - **Other errors**: Throws `StreamableHTTPError`

**Key Code**:
```javascript
const headers = await this._commonHeaders();
headers.set('content-type', 'application/json');
headers.set('accept', 'application/json, text/event-stream');

const init = {
    method: 'POST',
    headers,
    body: JSON.stringify(message),
    signal: this._abortController?.signal
};

const response = await (this._fetch ?? fetch)(this._url, init);
```

### 2. `start()` - Lines 256-261
**Purpose**: Initializes the transport and starts the connection

**What it does**:
- Creates an `AbortController` for managing request cancellation
- Called automatically by `Client.connect()`

### 3. `_startOrAuthSse(options)` - Lines 78-113
**Purpose**: Opens a Server-Sent Events (SSE) stream via HTTP GET to receive messages from the server

**What it does**:
- Sends a GET request with:
  - `Accept: text/event-stream`
  - `last-event-id` header (if resuming from a previous event)
  - Session ID and auth headers
- Handles responses:
  - **200 OK**: Starts processing the SSE stream
  - **401 Unauthorized**: Triggers authentication
  - **405 Method Not Allowed**: Server doesn't support SSE (expected, not an error)
  - **Other errors**: Throws `StreamableHTTPError`

**Key Code**:
```javascript
const headers = await this._commonHeaders();
headers.set('Accept', 'text/event-stream');
if (resumptionToken) {
    headers.set('last-event-id', resumptionToken);
}

const response = await (this._fetch ?? fetch)(this._url, {
    method: 'GET',
    headers,
    signal: this._abortController?.signal
});
```

### 4. `_commonHeaders()` - Lines 58-77
**Purpose**: Builds common HTTP headers for all requests

**Headers included**:
- `Authorization: Bearer <token>` (if authenticated)
- `mcp-session-id` (if session exists)
- `mcp-protocol-version` (if protocol version is set)
- Any custom headers from `requestInit`

### 5. `terminateSession()` - Lines 431-456
**Purpose**: Explicitly terminates the session by sending HTTP DELETE

**What it does**:
- Sends DELETE request with `mcp-session-id` header
- Handles **405 Method Not Allowed** as valid (server doesn't support termination)
- Clears the session ID on success

### 6. `_handleSseStream(body, options, isReconnectable)` - Lines 134-255
**Purpose**: Processes Server-Sent Events stream from the server

**What it does**:
- Parses SSE events from the response body
- Extracts JSON-RPC messages from event data
- Handles reconnection if stream disconnects
- Calls `onmessage` callback for each received message

## Request Flow

### Initialization Flow:
1. Client calls `atxpClient()` which creates a `StreamableHTTPClientTransport`
2. Client calls `connect()` which calls `start()`
3. Client sends `initialize` request via `send()`
4. Server responds with **202 Accepted** and `mcp-session-id` header
5. Client extracts session ID and stores it
6. Client starts SSE stream via `_startOrAuthSse()` to receive server messages

### Tool Call Flow:
1. Client calls `client.callTool({ name: 'add', arguments: { a: 5, b: 3 } })`
2. Client SDK creates JSON-RPC request: `{ "jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {...} }`
3. Client calls `transport.send(message)`
4. Transport sends POST request with:
   - Headers: `Content-Type: application/json`, `mcp-session-id: <session-id>`
   - Body: JSON-RPC request
5. Server processes request and responds with JSON-RPC response
6. Client receives response and calls `onmessage` callback

### Elicitation Flow:
1. Server sends elicitation request via `server.elicitInput()` during tool execution
2. Server sends JSON-RPC request: `{ "jsonrpc": "2.0", "id": 3, "method": "elicitation/create", "params": {...} }`
3. Client receives via SSE stream (or direct response)
4. Client's `setRequestHandler(ElicitRequestSchema, ...)` handler is called
5. Handler returns `{ action: "accept" }`
6. Client SDK wraps response: `{ "jsonrpc": "2.0", "id": 3, "result": { "action": "accept" } }`
7. Client sends response back to server via `send()`

## Error Handling

The transport handles several error scenarios:

1. **401 Unauthorized**: Automatically triggers OAuth authentication flow
2. **403 Forbidden with insufficient_scope**: Attempts to upscope permissions
3. **Network errors**: Triggers reconnection with exponential backoff
4. **SSE stream disconnects**: Automatically reconnects if resumable
5. **Other HTTP errors**: Throws `StreamableHTTPError` with status code and message

## Session Management

- Session ID is extracted from `mcp-session-id` response header during initialization
- Session ID is included in all subsequent requests via `mcp-session-id` header
- Session can be explicitly terminated via `terminateSession()` (DELETE request)
- Session cleanup happens automatically on transport close

