const { atxpClient, ATXPAccount } = require('@atxp/client')
const path = require('path')
const { exec } = require('child_process')
require('dotenv/config')

const account = new ATXPAccount(process.env.ATXP_CONNECTION)

async function main() {
    console.log('[CLIENT] Starting ATXP MCP client...');
    
    try {
        // Step 1: Create and connect client
        // Note: atxpClient() internally calls connect(), so the client is already connected when it resolves
        console.log('[CLIENT] Creating ATXP client and connecting...');
        const client = await atxpClient({
            mcpServer: 'http://localhost:3000',
            account: account,
            allowHttp: true, // Allow HTTP for local development
            clientOptions: {
                capabilities: {
                    elicitation: {
                        url: {}  // Declare support for URL mode elicitation
                    }
                }
            }
        });
        
        console.log('[CLIENT] Client connected successfully');
        
        // Get transport reference for manual message sending if needed
        const transport = client._transport;
        if (!transport) {
            throw new Error('Could not access transport from client');
        }
        console.log('[CLIENT] Transport reference obtained');
        
        // Set up elicitation request handler BEFORE any tool calls
        console.log('[CLIENT] Setting up elicitation request handler...');
        
        const { ElicitRequestSchema } = require(path.resolve(
            __dirname, 
            'node_modules/@modelcontextprotocol/sdk/dist/cjs/types.js'
        ));
        
        client.setRequestHandler(ElicitRequestSchema, async (request, extra) => {
            console.log('[ELICITATION] ========================================');
            console.log('[ELICITATION] Received elicitation request from server');
            console.log('[ELICITATION] Full request object:', JSON.stringify(request, null, 2));
            console.log('[ELICITATION] Extra object:', JSON.stringify(extra, null, 2));
            console.log('[ELICITATION] Request ID (from request):', request.id);
            console.log('[ELICITATION] Request ID (from extra):', extra?.requestId);
            console.log('[ELICITATION] Request method:', request.method);
            console.log('[ELICITATION] Request params:', JSON.stringify(request.params, null, 2));
            console.log('[ELICITATION] Request keys:', Object.keys(request));
            console.log('[ELICITATION] Extra keys:', extra ? Object.keys(extra) : 'none');
            
            // Try to access the raw message from the transport if possible
            if (transport && typeof transport._pendingRequests === 'object') {
                console.log('[ELICITATION] Transport pending requests:', Object.keys(transport._pendingRequests || {}));
            }
            console.log('[ELICITATION] ========================================');
            
            const params = request.params;
            // Try to get request ID from extra if not in request
            const requestId = request.id || extra?.requestId;
            
            // Handle URL mode elicitation requests
            if (params.mode === 'url') {
                const paymentUrl = params.url;
                const message = params.message;
                const elicitationId = params.elicitationId;
                
                console.log(`[ELICITATION] URL mode elicitation request:`);
                console.log(`  - Elicitation ID: ${elicitationId}`);
                console.log(`  - Message: ${message}`);
                console.log(`  - Payment URL: ${paymentUrl}`);
                
                // Open browser asynchronously (non-blocking)
                setImmediate(() => {
                    const platform = process.platform;
                    let command;
                    
                    if (platform === 'darwin') {
                        command = `open "${paymentUrl}"`;
                    } else if (platform === 'win32') {
                        command = `start "" "${paymentUrl}"`;
                    } else {
                        command = `xdg-open "${paymentUrl}"`;
                    }
                    
                    exec(command, (error) => {
                        if (error) {
                            console.error(`[ELICITATION] Failed to open browser: ${error.message}`);
                            console.log(`[ELICITATION] Please manually open: ${paymentUrl}`);
                        } else {
                            console.log(`[ELICITATION] Opened payment URL in browser`);
                        }
                    });
                });
            }
            
            // The SDK should automatically send the response, but if request ID is missing,
            // it won't be able to match it. Let's return the result and let SDK handle it.
            // If that doesn't work, we may need to manually send via transport.
            console.log('[ELICITATION] Returning accept response (SDK will send automatically)');
            console.log('[ELICITATION] Request ID for response:', requestId);
            
            if (!requestId) {
                console.error('[ELICITATION] WARNING: Request ID is undefined!');
                console.error('[ELICITATION] SDK may not be able to match response to server request.');
                console.error('[ELICITATION] This is likely a bug in the SDK or how the request is being parsed.');
            }
            
            // Return the result - SDK should handle sending the response
            return { action: "accept" };
        });
        
        console.log('[CLIENT] Elicitation request handler registered');
        
        // Call the tool - server will send elicitation request if payment required
        console.log('[CLIENT] Calling tool: add(5, 3)');
        const result = await client.callTool({
            name: 'add',
            arguments: { a: 5, b: 3 }
        });
        
        // Step 5: Handle the result
        if (result.isError) {
            console.error('[CLIENT] Tool call failed:');
            console.error(JSON.stringify(result, null, 2));
            throw new Error(result.content[0]?.text || 'Tool call failed');
        }
        
        console.log('[CLIENT] Tool call succeeded:');
        console.log(JSON.stringify(result, null, 2));
        console.log(`[CLIENT] Result: ${result.content[0].text}`);
        
    } catch (error) {
        console.error('[CLIENT] Error occurred:');
        console.error(error);
        
        // Log more details if available
        if (error.message) {
            console.error(`[CLIENT] Error message: ${error.message}`);
        }
        if (error.stack) {
            console.error(`[CLIENT] Stack trace: ${error.stack}`);
        }
        
        process.exit(1);
    }
}

// Handle process termination gracefully
process.on('SIGINT', () => {
    console.log('\n[CLIENT] Received SIGINT, shutting down...');
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('\n[CLIENT] Received SIGTERM, shutting down...');
    process.exit(0);
});

// Run the main function
main().catch((error) => {
    console.error('[CLIENT] Unhandled error in main():');
    console.error(error);
    process.exit(1);
});