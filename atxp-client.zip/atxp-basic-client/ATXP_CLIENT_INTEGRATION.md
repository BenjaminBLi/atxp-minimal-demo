# ATXP Client Integration with MCP Transport

This document explains how the ATXP client (`atxpClient`) integrates with the MCP `StreamableHTTPClientTransport` to add payment processing capabilities.

## Architecture Overview

The ATXP client wraps the MCP transport's `fetch` function with payment handling logic. This means **all HTTP requests** made by the transport automatically go through the ATXP payment layer first.

```
┌─────────────────────────────────────────────────────────────┐
│                    Your Application                         │
│  client.callTool({ name: 'add', arguments: { a: 5, b: 3 }})│
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              MCP Client (from SDK)                          │
│  - Creates JSON-RPC requests                               │
│  - Manages session state                                    │
│  - Handles elicitation requests                            │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│      StreamableHTTPClientTransport                         │
│  - transport.send() → POST requests                        │
│  - _startOrAuthSse() → GET requests (SSE)                   │
│  - Uses: this._fetch ?? fetch                              │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│           ATXP Wrapped Fetch (atxpFetch)                    │
│  - Intercepts ALL HTTP requests                             │
│  - Detects payment requirements (402 Payment Required)     │
│  - Handles OAuth authentication                            │
│  - Processes payments via blockchain                        │
│  - Retries original request after payment                   │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              MCP Server (Express)                          │
│  - Receives JSON-RPC requests                              │
│  - Processes tool calls                                    │
│  - Returns responses with payment requirements              │
└─────────────────────────────────────────────────────────────┘
```

## Key Integration Points

### 1. `atxpClient()` Function

**Location**: `@atxp/client/dist/atxpClient.js`

**What it does**:
1. Builds client configuration from arguments
2. Creates a wrapped fetch function using `atxpFetch(config)`
3. Creates `StreamableHTTPClientTransport` with the wrapped fetch
4. Creates MCP `Client` instance
5. Connects the client to the transport

**Code**:
```javascript
async function atxpClient(args) {
    const config = buildClientConfig(args);
    const transport = buildStreamableTransport(config);  // Uses wrapped fetch
    const client = new Client(config.clientInfo, config.clientOptions);
    await client.connect(transport);
    return client;
}
```

### 2. `buildStreamableTransport()` Function

**Location**: `@atxp/client/dist/atxpClient.js`

**What it does**:
1. Builds the client configuration
2. Wraps the fetch function with `atxpFetch(config)` - this adds payment handling
3. Creates `StreamableHTTPClientTransport` with the wrapped fetch
4. Returns the transport

**Code**:
```javascript
function buildStreamableTransport(args) {
    const config = buildClientConfig(args);
    // Apply the ATXP wrapper to the fetch function
    const wrappedFetch = atxpFetch(config);
    const transport = new StreamableHTTPClientTransport(
        new URL(args.mcpServer), 
        { fetch: wrappedFetch }  // ← Wrapped fetch passed here
    );
    return transport;
}
```

### 3. `atxpFetch()` Function

**Location**: `@atxp/client/dist/atxpFetcher.js`

**What it does**:
- **Intercepts all HTTP requests** made by the transport
- Detects `402 Payment Required` responses from the server
- Extracts payment information from response headers/body
- Handles OAuth authentication if needed
- Processes payments via blockchain (using the provided `account`)
- **Retries the original request** after payment is complete
- Handles payment errors and retries across multiple networks

**Key Flow**:
1. Original request is made to MCP server
2. Server responds with `402 Payment Required` + payment details
3. `atxpFetch` intercepts the 402 response
4. User is prompted/auto-approved for payment (via `approvePayment` callback)
5. Payment is processed on blockchain
6. Original request is automatically retried
7. Server processes the request (payment now complete)
8. Response is returned to the transport

## Request Flow with Payment

### Normal Request (No Payment Required):
```
1. client.callTool() 
   → 2. transport.send() 
   → 3. wrappedFetch() (atxpFetch) 
   → 4. Server responds 200 OK
   → 5. Response returned to client
```

### Request Requiring Payment:
```
1. client.callTool() 
   → 2. transport.send() 
   → 3. wrappedFetch() (atxpFetch) 
   → 4. Server responds 402 Payment Required
   → 5. atxpFetch intercepts 402
   → 6. Payment processed on blockchain
   → 7. Original request retried automatically
   → 8. Server responds 200 OK (payment complete)
   → 9. Response returned to client
```

### Request with Elicitation (Current Implementation):
```
1. client.callTool() 
   → 2. transport.send() 
   → 3. wrappedFetch() (atxpFetch) 
   → 4. Server responds 200 OK with elicitation request
   → 5. Client receives elicitation via SSE stream
   → 6. Client's setRequestHandler() processes elicitation
   → 7. Client sends elicitation response
   → 8. Server processes payment (elicitation accepted)
   → 9. Tool execution continues
   → 10. Final response returned
```

## How Transport Uses the Wrapped Fetch

The `StreamableHTTPClientTransport` uses the wrapped fetch in two places:

### 1. POST Requests (`send()` method):
```javascript
const response = await (this._fetch ?? fetch)(this._url, init);
// ↑ Uses wrapped fetch if provided, otherwise native fetch
```

### 2. GET Requests (`_startOrAuthSse()` method):
```javascript
const response = await (this._fetch ?? fetch)(this._url, {
    method: 'GET',
    headers,
    signal: this._abortController?.signal
});
// ↑ Uses wrapped fetch if provided, otherwise native fetch
```

## Payment Processing Details

When `atxpFetch` detects a payment requirement:

1. **Extracts Payment Info**: From `402 Payment Required` response headers:
   - `X-Payment-Request-Url`: URL to complete payment
   - `X-Payment-Request-Id`: Unique payment request ID
   - `X-Charge-Amount`: Amount to pay
   - `X-Charge-Currency`: Currency (e.g., "USDC")

2. **User Approval**: Calls `config.approvePayment(payment)` callback
   - Returns `true` if user approves, `false` if rejected
   - In your demo, this is auto-approved

3. **Payment Execution**: 
   - Creates blockchain transaction
   - Signs transaction using provided `account`
   - Submits transaction to network
   - Waits for confirmation

4. **Request Retry**: After payment succeeds, automatically retries the original request

5. **Error Handling**: If payment fails:
   - Tries alternative networks (if configured)
   - Throws appropriate error (`InsufficientFundsError`, `UserRejectedError`, etc.)
   - Calls `onPaymentFailure` callback

## Benefits of This Architecture

1. **Transparent**: Payment handling is invisible to the MCP transport layer
2. **Automatic**: Payments are processed automatically when required
3. **Retry Logic**: Failed payments can retry on different networks
4. **Error Handling**: Comprehensive error handling with actionable messages
5. **OAuth Integration**: Seamlessly handles OAuth authentication for protected resources

## Current Implementation Note

In your current setup, the server uses **elicitation requests** instead of `402 Payment Required` responses. This means:

- The `atxpFetch` payment interception doesn't trigger (no 402 response)
- Instead, the server sends an elicitation request via JSON-RPC
- The client handles the elicitation via `setRequestHandler()`
- Payment is processed after elicitation is accepted

This is a different flow than the standard ATXP payment flow, but both approaches work. The elicitation approach gives more control over the payment UI/UX.

